#!/bin/bash

chmod +x compile.sh
chmod +x run.sh

./compile.sh
./run.sh
