#!/bin/bash

echo "Suppression des anciens fichiers .class..."
find ./src -name "*.class" -delete

echo "Compilation du projet..."
javac -d ./bin ./src/miniSGBDR/*.java

if [ $? -eq 0 ]; then
  echo "Compilation réussie !"
else
  echo "Erreur lors de la compilation."
  exit 1
fi
