package miniSGBDR;

public enum Operator {
    EQ, LT, GT, LE, GE, NE
}
