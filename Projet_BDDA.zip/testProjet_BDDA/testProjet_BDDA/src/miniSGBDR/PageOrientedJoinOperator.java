package miniSGBDR;

import java.util.List;

public class PageOrientedJoinOperator implements IRecordIterator {
    private int currentIdx;
    private List<Record> records;

    public Record GetNextRecord(){
        return null;
    };
    public void Close(){};
    public void Reset(){
        currentIdx = 0;
    };


}
