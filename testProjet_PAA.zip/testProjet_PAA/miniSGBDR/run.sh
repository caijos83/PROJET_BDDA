#!/bin/bash

# Lancement du projet
echo "Lancement de l'application SGBD..."
java -cp ./bin miniSGBDR.SGBD

if [ $? -eq 0 ]; then
  echo "Exécution terminée."
else
  echo "Erreur lors de l'exécution."
  exit 1
fi
