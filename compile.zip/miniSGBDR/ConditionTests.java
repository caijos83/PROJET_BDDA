package miniSGBDR;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class ConditionTests {
    public static void main(String[] args) throws IOException {
        // Configuration minimale
        DBConfig config = new DBConfig(".\\Data", 4096, 1048576, DBConfig.BMpolicy.LRU, 5);
        DiskManager diskManager = new DiskManager(config);
        BufferManager bufferManager = new BufferManager(config, diskManager);

        // On alloue une page pour le header de la relation
        PageId headerPageId = diskManager.allocPage();

        // Définition du schéma
        List<String> colNames = Arrays.asList("ID", "Name", "Age");
        List<String> colTypes = Arrays.asList("INT", "VARCHAR(10)", "INT");

        // Création de la relation
        Relation relation = new Relation("TestRelation", colNames, colTypes,
                headerPageId, diskManager, bufferManager, config);
        // Init du header page
        relation.initHeaderPage();

        // Création d'un record de test
        Record record = new Record();
        record.addValue(10);        // ID (INT)
        record.addValue("Alice");   // Name (VARCHAR(10))
        record.addValue(30);        // Age (INT)

//        testEqualityCondition(relation, record);
//        testInequalityCondition(relation, record);
//        testGreaterLessConditions(relation, record);
//        testLeftRightColConditions(relation, record);
//        testConstantOnLeftSide(relation, record);

//        System.out.println("All ConditionTests passed successfully!");
    }

    public static void testEqualityCondition(Relation rel, Record record) {
        // ID = 10
        Condition c = new Condition(0, Operator.EQ, 10);
        assert c.evaluate(record, rel) : "ID=10 failed!";

        // Name = "Alice"
        c = new Condition(1, Operator.EQ, "Alice");
        assert c.evaluate(record, rel) : "Name='Alice' failed!";

        // Age = 25 (faux)
        c = new Condition(2, Operator.EQ, 25);
        assert !c.evaluate(record, rel) : "Age=25 should fail!";

        System.out.println("testEqualityCondition passed.");
    }

    public static void testInequalityCondition(Relation rel, Record record) {
        // Age!=25 (vrai, Age=30)
        Condition c = new Condition(2, Operator.NE, 25);
        assert c.evaluate(record, rel) : "Age!=25 failed!";

        // Name!="Bob" (vrai, Name="Alice")
        c = new Condition(1, Operator.NE, "Bob");
        assert c.evaluate(record, rel) : "Name!='Bob' failed!";

        // ID!=10 (faux, ID=10)
        c = new Condition(0, Operator.NE, 10);
        assert !c.evaluate(record, rel) : "ID!=10 should fail!";

        System.out.println("testInequalityCondition passed.");
    }

    public static void testGreaterLessConditions(Relation rel, Record record) {
        // Age=30
        // Age > 20 (vrai)
        Condition c = new Condition(2, Operator.GT, 20);
        assert c.evaluate(record, rel) : "Age>20 failed!";

        // Age < 35 (vrai)
        c = new Condition(2, Operator.LT, 35);
        assert c.evaluate(record, rel) : "Age<35 failed!";

        // Age <= 30 (vrai)
        c = new Condition(2, Operator.LE, 30);
        assert c.evaluate(record, rel) : "Age<=30 failed!";

        // Age >=31 (faux, Age=30)
        c = new Condition(2, Operator.GE, 31);
        assert !c.evaluate(record, rel) : "Age>=31 should fail!";

        System.out.println("testGreaterLessConditions passed.");
    }

    public static void testLeftRightColConditions(Relation rel, Record record) {
        // ID=10, Age=30
        // ID < Age ?
        Condition c = new Condition(0, Operator.LT, 2); // colLeft=ID, colRight=Age
        assert c.evaluate(record, rel) : "ID<Age failed!";

        // Age < Name lexicographiquement ? Age=30, Name="Alice"
        // "30".compareTo("Alice"): '3'(51) vs 'A'(65), "30"<"Alice"
        c = new Condition(2, Operator.LT, 1); // Age < Name
        assert c.evaluate(record, rel) : "Age<Name lexicographic failed!";

        // Name > ID lexicographiquement ? "Alice" vs "10"
        // 'A'(65) > '1'(49), vrai
        c = new Condition(1, Operator.GT, 0); // Name > ID
        assert c.evaluate(record, rel) : "Name>ID lexicographic failed!";

        System.out.println("testLeftRightColConditions passed.");
    }

    public static void testConstantOnLeftSide(Relation rel, Record record) {
        // (constant, op, colIndex)
        // 5 < Age=30 ? vrai
        Condition c = new Condition(5, Operator.LT, 2);
        assert c.evaluate(record, rel) : "5<Age failed!";

        // "Zorro" > Name="Alice" ? "Zorro".compareTo("Alice")=Z>A donc vrai
        c = new Condition("Zorro", Operator.GT, 1);
        assert c.evaluate(record, rel) : "Zorro>Name failed!";

        // 40 > Age=30 ? vrai
        c = new Condition(40, Operator.GT, 2);
        assert c.evaluate(record, rel) : "40>Age failed!";

        // "Bob" = Name="Alice" ? faux
        c = new Condition("Bob", Operator.EQ, 1);
        assert !c.evaluate(record, rel) : "Bob=Alice should fail!";

        System.out.println("testConstantOnLeftSide passed.");
    }
}
