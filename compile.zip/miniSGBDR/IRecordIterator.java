package miniSGBDR;

public interface IRecordIterator {
    Record GetNextRecord() throws Exception;
    void Close();
    void Reset();
}
