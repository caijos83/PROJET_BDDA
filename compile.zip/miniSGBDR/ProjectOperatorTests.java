package miniSGBDR;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ProjectOperatorTests {
    public static void main(String[] args) throws Exception{
        // Créer quelques records d'entrée
        Record r1 = new Record();
        r1.addValue(1);
        r1.addValue("Alice");
        r1.addValue(30);

        Record r2 = new Record();
        r2.addValue(2);
        r2.addValue("Bob");
        r2.addValue(25);

        Record r3 = new Record();
        r3.addValue(3);
        r3.addValue("Charlie");
        r3.addValue(40);

        List<Record> inputRecords = Arrays.asList(r1, r2, r3);

        // Créer un iterateur mock
        IRecordIterator mockChild = new MockIterator(inputRecords);

        // Test 1: Projection sur toutes les colonnes (0,1,2)
        // Attendu : les mêmes records
        testFullProjection(mockChild);

        // Test 2: Projection sur une seule colonne (par ex: juste la colonne 1, "Name")
        testSingleColumnProjection(new MockIterator(inputRecords));

        // Test 3: Projection sur deux colonnes (0 et 2, ID et Age)
        testPartialProjection(new MockIterator(inputRecords));

        System.out.println("All ProjectOperatorTests passed successfully!");
    }

    public static void testFullProjection(IRecordIterator child) throws Exception{
        List<Integer> allCols = Arrays.asList(0,1,2);
        ProjectOperator proj = new ProjectOperator(child, allCols);

        Record r;
        int count = 0;
        while ((r = proj.GetNextRecord()) != null) {
            // L'enregistrement devrait être le même que l'original
            // Car on projette toutes les colonnes
            if (count == 0) {
                assert r.getValues().equals(Arrays.asList(1, "Alice", 30)) : "Full projection mismatch for first record!";
            } else if (count == 1) {
                assert r.getValues().equals(Arrays.asList(2, "Bob", 25)) : "Full projection mismatch for second record!";
            } else if (count == 2) {
                assert r.getValues().equals(Arrays.asList(3, "Charlie", 40)) : "Full projection mismatch for third record!";
            }
            count++;
        }
        assert count == 3 : "Expected 3 records from full projection!";
        proj.Close();

        System.out.println("testFullProjection passed.");
    }

    public static void testSingleColumnProjection(IRecordIterator child) throws Exception {
        // On projette juste la colonne 1 (Name)
        List<Integer> nameCol = Arrays.asList(1);
        ProjectOperator proj = new ProjectOperator(child, nameCol);

        Record r;
        int count = 0;
        List<List<Object>> expected = Arrays.asList(
            Arrays.asList("Alice"),
            Arrays.asList("Bob"),
            Arrays.asList("Charlie")
        );

        while ((r = proj.GetNextRecord()) != null) {
            assert r.getValues().equals(expected.get(count)) : "Single column projection mismatch at record " + count;
            count++;
        }

        assert count == 3 : "Expected 3 records from single column projection!";
        proj.Close();

        System.out.println("testSingleColumnProjection passed.");
    }

    public static void testPartialProjection(IRecordIterator child) throws Exception {
        // Projeter les colonnes 0 (ID) et 2 (Age)
        List<Integer> cols = Arrays.asList(0, 2);
        ProjectOperator proj = new ProjectOperator(child, cols);

        Record r;
        int count = 0;
        List<List<Object>> expected = Arrays.asList(
            Arrays.asList(1, 30),
            Arrays.asList(2, 25),
            Arrays.asList(3, 40)
        );

        while ((r = proj.GetNextRecord()) != null) {
            assert r.getValues().equals(expected.get(count)) : "Partial projection mismatch at record " + count;
            count++;
        }

        assert count == 3 : "Expected 3 records from partial projection!";
        proj.Close();

        System.out.println("testPartialProjection passed.");
    }
}

// MockIterator : un IRecordIterator simple retournant une liste fixe de records
class MockIterator implements IRecordIterator {
    private List<Record> records;
    private int current;

    public MockIterator(List<Record> records) {
        this.records = new ArrayList<>(records); // copie pour sécurité
        this.current = 0;
    }

    @Override
    public Record GetNextRecord() {
        if (current < records.size()) {
            return records.get(current++);
        }
        return null;
    }

    @Override
    public void Close() {
        // rien de spécial
    }

    @Override
    public void Reset() {
        current = 0;
    }
}
