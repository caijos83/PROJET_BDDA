package miniSGBDR;

import java.nio.ByteBuffer;

public class DataPageHoldRecordIterator implements IRecordIterator{

//    private Record currentRecord;
    private ByteBuffer buffer;
    private int currentSlot;
    private int totalSlots;
    private int pageSize;
    private Relation relation;
    private PageId pageId;
    private boolean closed;

    public DataPageHoldRecordIterator(Relation relation, PageId pageId) throws Exception{
        this.relation = relation;
        this.pageId = pageId;
        this.closed = false;

        buffer = relation.getBufferManager().getPage(pageId);
        pageSize = relation.getConfig().getPagesize();

        // Lire le nombre de slots
        buffer.position(pageSize - 8);
        totalSlots = buffer.getInt();
        currentSlot = 0;

    }

    public Record GetNextRecord(){
        if(closed){
            System.out.println("Iterator is closed");
            return null;
        }
        while(currentSlot < totalSlots){
            int slotPos = pageSize -8 - (currentSlot+1)*8;
            buffer.position(slotPos);
            int startPos = buffer.getInt();
            int length = buffer.getInt();
            currentSlot++;
            if(length > 0 ){
                Record record = new Record();
                relation.readFromBuffer(record, buffer, startPos); 
                return record;
            }
        }

        return null;
    }

    public void Close(){
        if(!closed){
            relation.getBufferManager().freePage(pageId, true);
            closed = true;
        }


    }

    public void Reset(){
        if(closed){
            System.out.println("Iterator is closed");
            return;
        }
        currentSlot = 0;
    }

}
