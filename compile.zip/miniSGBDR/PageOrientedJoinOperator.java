package miniSGBDR;

import java.io.IOException;

public class PageOrientedJoinOperator implements IRecordIterator {

    private IRecordIterator outerIterator;
    private PageDirectoryIterator innerPageDirectoryIterator;
    private IRecordIterator innerRecordIterator;
    private Condition [] conditions;
    private Relation rel1;
    private Relation rel2;
    private boolean closed;
    
    

    public PageOrientedJoinOperator(Relation  rel1, Relation rel2, Condition[] conditions) throws Exception{
        this.rel1 = rel1;
        this.rel2 = rel2;
        this.conditions = conditions;
        this.closed = false;

        this.outerIterator = new RelationScanner(rel1); // Vous devrez implémenter RecordIterator
        this.innerPageDirectoryIterator = new PageDirectoryIterator(rel2.getBufferManager() ,rel2.getHeaderPageId());
        this.innerRecordIterator = null;
    }


    public Record GetNextRecord() throws Exception{
        if(closed){
            System.out.println("Join operator is closed.");
            return null;
        }


        while (true) {
            Record outerRecord = outerIterator.GetNextRecord();
            if (outerRecord == null) {
                return null; // Plus de records à traiter
            }

            // Réinitialiser l'itérateur interne
            innerPageDirectoryIterator.Reset();

            while (true) {
                PageId innerPageId = innerPageDirectoryIterator.GetNextDataPageId();
                if (innerPageId == null) {
                    break; // Plus de pages internes
                }

                if(innerRecordIterator != null){
                    innerRecordIterator.Close();
                }


                innerRecordIterator = new DataPageHoldRecordIterator(rel2, innerPageId);

                Record innerRecord;
                while ((innerRecord = innerRecordIterator.GetNextRecord()) != null) {
                    if (evaluateJoinConditions(outerRecord, innerRecord)) {
                        // Créer un nouveau record combiné
                        Record joinedRecord = new Record();
                        joinedRecord.getValues().addAll(outerRecord.getValues());
                        joinedRecord.getValues().addAll(innerRecord.getValues());
                        return joinedRecord;
                    }
                }

                innerRecordIterator.Close();
                innerRecordIterator = null;    

            }

        }
    }



private boolean evaluateJoinConditions(Record r1, Record r2) {
    for(Condition condition: conditions){

 //       if(!condition.evaluate(r1, r2)){
 //           return false;
 //       }

    }

    return true;
}

    
    public void Close(){
        if(!closed){
            outerIterator.Close();
            innerPageDirectoryIterator.Close();
            if(innerRecordIterator != null){
                innerRecordIterator.Close();
            }
            closed=true;
        }

    }
    public void Reset(){
        if(closed){
            System.out.println("Join operator is closed.");
            return;
        }

        outerIterator.Reset();
        innerRecordIterator.Reset();
        if(innerRecordIterator != null){
            innerRecordIterator.Close();
            innerRecordIterator=null;
        }
    }

}
