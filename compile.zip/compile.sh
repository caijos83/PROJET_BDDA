#!/bin/bash
echo "Compiling the project..."

# Définir le répertoire source et le répertoire de sortie
SRC_DIR="miniSGBDR"
BIN_DIR="bin"

# Créer le dossier pour les fichiers compilés
if [ ! -d "$BIN_DIR" ]; then
  mkdir "$BIN_DIR"
fi

# Compiler tous les fichiers Java
javac -d "$BIN_DIR" "$SRC_DIR"/*.java

# Vérification de la compilation
if [ $? -ne 0 ]; then
  echo "Compilation failed."
  exit 1
fi

echo "Compilation completed successfully."
