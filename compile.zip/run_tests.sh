#!/bin/bash
echo "Running tests..."

# Répertoire des classes compilées
BIN_DIR="bin"

# Tester les classes une par une
java -cp "$BIN_DIR" miniSGBDR.BufferManagerTests
if [ $? -ne 0 ]; then echo "BufferManagerTests failed."; exit 1; fi

java -cp "$BIN_DIR" miniSGBDR.DBConfigTests
if [ $? -ne 0 ]; then echo "DBConfigTests failed."; exit 1; fi

java -cp "$BIN_DIR" miniSGBDR.DiskManagerTests
if [ $? -ne 0 ]; then echo "DiskManagerTests failed."; exit 1; fi

java -cp "$BIN_DIR" miniSGBDR.RecordTests
if [ $? -ne 0 ]; then echo "RecordTests failed."; exit 1; fi

java -cp "$BIN_DIR" miniSGBDR.RelationTests
if [ $? -ne 0 ]; then echo "RelationTests failed."; exit 1; fi

echo "All tests ran successfully."
