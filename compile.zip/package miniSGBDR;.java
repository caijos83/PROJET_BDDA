package miniSGBDR;

import java.io.*;
import java.nio.ByteBuffer;
import java.util.*;

public class DBManager {
    private Map<String, Map<String, Relation>> databases; // Stocke les bases de données et leurs tables
    private String currentDatabase;
    private DBConfig config;

    // Constructeur
    public DBManager(DBConfig config) {
        this.config = config;
        this.databases = new HashMap<>();
        this.currentDatabase = null;
    }

    // Créer une base de données
    public void createDatabase(String dbName) {
        if (!databases.containsKey(dbName)) {
            databases.put(dbName, new HashMap<>());
            System.out.println("Database " + dbName + " created.");
        }
        // Si la base de données existe déjà
        else {
            System.out.println("Database " + dbName + " already exists.");
        }
    }

    // Définir la base de données active
    public void setCurrentDatabase(String dbName) {
        if (databases.containsKey(dbName)) {
            currentDatabase = dbName;
            System.out.println("Current database set to " + dbName + ".");
        } else {
            System.out.println("Database " + dbName + " does not exist.");
        }
    }

    // Ajouter une table à la base de données active
    public void addTableToCurrentDatabase(Relation table) {
        if (currentDatabase == null) {
            System.out.println("No active database. Use SET DATABASE to select one.");
            return;
        }
        Map<String, Relation> tables = databases.get(currentDatabase);
        if (!tables.containsKey(table.getName())) {
            tables.put(table.getName(), table);
            System.out.println("Table " + table.getName() + " added to " + currentDatabase + ".");
        }
    }

    // Récupérer une table de la base de données active
    public Relation getTableFromCurrentDatabase(String tableName) {
        if (currentDatabase == null) {
            System.out.println("No active database.");
            return null;
        }
        Map<String, Relation> tables = databases.get(currentDatabase);
        Relation table = tables.get(tableName);
        
        if(table == null) {
            System.out.println("No table " + tableName + " in the current database.");
            return null;
        }

        return table;
    }

        // Supprimer une table de la base de données active
        public void removeTableFromCurrentDatabase(String tableName) {
            if (currentDatabase == null) {
                System.out.println("No active database.");
                return;
            }
            Map<String, Relation> tables = databases.get(currentDatabase);

            if (tables.remove(tableName) != null) {
                System.out.println("Table " + tableName + " removed from " + currentDatabase + ".");
            }
            else {
                System.out.println("Table " + tableName + " does not exist in " + currentDatabase + ".");
            }
        }


    // Supprimer une base de données
    public void removeDatabase(String dbName) {
        if (databases.containsKey(dbName)) {
            databases.remove(dbName);
            System.out.println("Database " + dbName + " removed.");

            if (dbName.equals(currentDatabase)) {
                currentDatabase = null;
                System.out.println("The active database has been reset.");
            }
        } else {
            System.out.println("Database " + dbName + " does not exist.");
        }
    }


    // Lister les bases de données
    public void listDatabases() {
        System.out.println("Databases:");
        for (String dbName : databases.keySet()) {
            System.out.println(dbName);
        }
    }

    // Lister les tables dans la base courante
    public void listTablesInCurrentDatabase() {
        if (currentDatabase == null) {
            System.out.println("No active database.");
            return;
        }
        System.out.println("Tables in " + currentDatabase + ":");
        Map<String, Relation> tables = databases.get(currentDatabase);
        for (Relation table : tables.values()) {
            System.out.println("- " + table.getName() + ": " + table.getColumnNames());
        }
    }


    public void dropTable(String tableName, DiskManager diskManager) throws IOException {
        if (currentDatabase == null) {
            System.out.println("No active database.");
            return;
        }

        Map<String, Relation> tables = databases.get(currentDatabase);

        Relation relation = tables.remove(tableName);
        if (relation != null) {
            List<PageId> pageIds = diskManager.getPagesForTable(tableName); // Récupère les pages associées
            for (PageId pageId : pageIds) {
                diskManager.deallocPage(pageId); // Libère chaque page
            }
            System.out.println("Table " + tableName + " dropped from " + currentDatabase + ".");
        } else {
            System.out.println("Table " + tableName + " does not exist.");
        }
    }

    public void dropAllTables(DiskManager diskManager) throws IOException {
        if (currentDatabase == null) {
            System.out.println("No active database. Use SET DATABASE to select one.");
            return;
        }

        Map<String, Relation> tables = databases.get(currentDatabase);

        // Parcourir et supprimer toutes les tables
        for (String tableName : new ArrayList<>(tables.keySet())) {
            dropTable(tableName, diskManager); // Réutilise dropTable
        }

        System.out.println("All tables in " + currentDatabase + " have been dropped.");
    }

    public void dropAllDatabases(DiskManager diskManager) throws IOException {
        for (String dbName : new ArrayList<>(databases.keySet())) {
            setCurrentDatabase(dbName);
            dropAllTables(diskManager);
            databases.remove(dbName);
        }
        currentDatabase = null;
        System.out.println("All databases have been dropped.");
    }







    public String getCurrentDatabaseName() {
        return currentDatabase;
    }









    // Sauvegarder l'état du DBManager
    public void saveState() throws IOException {

    }

    // Charger l'état du DBManager
    @SuppressWarnings("unchecked")
    public void loadState() throws IOException, ClassNotFoundException {


}
